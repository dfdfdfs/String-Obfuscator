#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_COMMAND_LENGTH 1024

int main() {
  char command[MAX_COMMAND_LENGTH];
  char *args[MAX_COMMAND_LENGTH / 2];

  while (1) {
    printf("> ");
    fgets(command, MAX_COMMAND_LENGTH, stdin);

    // Удаляем символ новой строки
    command[strchr(command, '\n') - command] = '\0';

    // Разбиваем команду на аргументы
    int i = 0;
    args[i] = strtok(command, " ");
    while (args[i] != NULL) {
      i++;
      args[i] = strtok(NULL, " ");
    }

    // Создаем дочерний процесс
    pid_t pid = fork();

    if (pid == -1) {
      perror("fork");
      exit(EXIT_FAILURE);
    } else if (pid == 0) {
      // Дочерний процесс выполняет команду
      execvp(args[0], args);
      perror("execvp");
      exit(EXIT_FAILURE);
    } else {
      // Родительский процесс ожидает завершения дочернего
      int status;
      waitpid(pid, &status, 0);

      if (WIFEXITED(status)) {
        printf("Команда завершена с кодом %d\n", WEXITSTATUS(status));
      } else if (WIFSIGNALED(status)) {
        printf("Команда завершена сигналом %d\n", WTERMSIG(status));
      }
    }
  }

  return 0;
}