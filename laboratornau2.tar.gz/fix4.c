#define _XOPEN_SOURCE 700  // Для ftw и некоторых других функций
#define _FILE_OFFSET_BITS 64 // Для поддержки больших файлов

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ftw.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <openssl/sha.h>  // Для вычисления SHA256 хеша

#define SHA256_DIGEST_LENGTH 32
#define BUFFER_SIZE 4096

typedef struct {
    char *path;
    size_t size;
    time_t creation_time; // Используем time_t для хранения времени создания
    mode_t permissions;
    ino_t inode;
    unsigned char sha256_hash[SHA256_DIGEST_LENGTH]; // Добавляем хеш
} FileInfo;


// Функция для вычисления SHA256 хеша файла
int calculate_sha256(const char *filepath, unsigned char *hash) {
    FILE *file = fopen(filepath, "rb");
    if (!file) {
        perror("Error opening file for hashing");
        return -1;
    }

    SHA256_CTX sha256_context;
    SHA256_Init(&sha256_context);

    unsigned char buffer[BUFFER_SIZE];
    size_t bytes_read;

    while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) != 0) {
        SHA256_Update(&sha256_context, buffer, bytes_read);
    }

    if (ferror(file)) {
        perror("Error reading file for hashing");
        fclose(file);
        return -1;
    }

    SHA256_Final(hash, &sha256_context);
    fclose(file);
    return 0;
}



// Функция для сбора информации о файле
FileInfo* get_file_info(const char *filepath) {
    struct stat file_stat;
    if (stat(filepath, &file_stat) == -1) {
        perror("stat");
        return NULL;
    }

    FileInfo *file_info = (FileInfo *)malloc(sizeof(FileInfo));
    if (!file_info) {
        perror("malloc");
        return NULL;
    }

    file_info->path = strdup(filepath); // Копируем путь, чтобы не зависеть от области видимости filepath
    if (!file_info->path) {
        perror("strdup");
        free(file_info);
        return NULL;
    }

    file_info->size = file_stat.st_size;
    file_info->creation_time = file_stat.st_ctime; // Получаем время создания
    file_info->permissions = file_stat.st_mode;
    file_info->inode = file_stat.st_ino;

    if (calculate_sha256(filepath, file_info->sha256_hash) != 0) {
        free(file_info->path);
        free(file_info);
        return NULL;
    }

    return file_info;
}


// Функция для сравнения двух FileInfo структур по хешу
int compare_file_info(const FileInfo *file1, const FileInfo *file2) {
    if (file1->size != file2->size) {
        return 1; // Разный размер - файлы разные
    }

    return memcmp(file1->sha256_hash, file2->sha256_hash, SHA256_DIGEST_LENGTH);
}


// Структура для хранения списка FileInfo
typedef struct {
    FileInfo **files;
    size_t count;
    size_t capacity;
} FileList;

// Инициализация списка файлов
void file_list_init(FileList *list) {
    list->files = NULL;
    list->count = 0;
    list->capacity = 0;
}

// Добавление файла в список
int file_list_add(FileList *list, FileInfo *file) {
    if (list->count == list->capacity) {
        list->capacity = (list->capacity == 0) ? 4 : list->capacity * 2;
        FileInfo **new_files = (FileInfo **)realloc(list->files, list->capacity * sizeof(FileInfo *));
        if (!new_files) {
            perror("realloc");
            return -1;
        }
        list->files = new_files;
    }
    list->files[list->count++] = file;
    return 0;
}

// Освобождение памяти, занятой списком файлов
void file_list_free(FileList *list) {
    for (size_t i = 0; i < list->count; i++) {
        free(list->files[i]->path);
        free(list->files[i]);
    }
    free(list->files);
    list->files = NULL;
    list->count = 0;
    list->capacity = 0;
}


// Глобальная переменная для передачи FileList в process_file (плохой стиль!)
FileList *global_file_list;


// Функция для обработки каждого файла, вызываемая ftw
int process_file(const char *filepath, const struct stat *sb, int typeflag) {
    if (typeflag == FTW_F) { // Обрабатываем только файлы
        FileInfo *file_info = get_file_info(filepath);
        if (file_info) {
            if (file_list_add(global_file_list, file_info) != 0) {
                // Обработка ошибки добавления в список
                free(file_info->path);
                free(file_info);
            }
        }
    }
    return 0; // Продолжаем обход дерева
}


// Функция для обхода дерева каталогов и сбора информации о файлах
int traverse_directory(const char *dirpath, FileList *file_list) {
    int flags = FTW_PHYS; // Не переходить по символическим ссылкам
    int nopenfd = 20;     // Максимальное число открытых файловых дескрипторов

    global_file_list = file_list; // Устанавливаем глобальную переменную

    if (ftw(dirpath,  process_file, nopenfd) == -1) {
        perror("ftw");
        return -1;
    }
    return 0;
}


// Функция для печати информации о файле
void print_file_info(FILE *output, const FileInfo *file_info) {
    char time_buffer[80];
    struct tm *tm_info = localtime(&file_info->creation_time);
    strftime(time_buffer, sizeof(time_buffer), "%Y-%m-%d %H:%M:%S", tm_info);

    fprintf(output, "Путь: %s\n", file_info->path);
    fprintf(output, "Размер: %zu bytes\n", file_info->size);
    fprintf(output, "Дата создания: %s\n", time_buffer);
    fprintf(output, "Разрешения: %o\n", file_info->permissions & 0777); // Mask for permissions
    fprintf(output, "Номер дискриптора: %lu\n", (unsigned long)file_info->inode);
    fprintf(output, "\n");
}




int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(stderr, "Usage: %s <directory1> <directory2> <output_file>\n", argv[0]);
        return 1;
    }

    const char *dir1_path = argv[1];
    const char *dir2_path = argv[2];
    const char *output_file_path = argv[3];

    FileList dir1_files;
    FileList dir2_files;

    file_list_init(&dir1_files);
    file_list_init(&dir2_files);

    // Обходим первый каталог
    if (traverse_directory(dir1_path, &dir1_files) != 0) {
        fprintf(stderr, "Error traversing directory: %s\n", dir1_path);
        file_list_free(&dir1_files);
        file_list_free(&dir2_files);
        return 1;
    }

    // Обходим второй каталог
    if (traverse_directory(dir2_path, &dir2_files) != 0) {
        fprintf(stderr, "Error traversing directory: %s\n", dir2_path);
        file_list_free(&dir1_files);
        file_list_free(&dir2_files);
        return 1;
    }

    // Открываем файл для записи результатов
    FILE *output_file = fopen(output_file_path, "w");
    if (!output_file) {
        perror("Error opening output file");
        file_list_free(&dir1_files);
        file_list_free(&dir2_files);
        return 1;
    }

    // Сравниваем файлы и выводим совпадающие
    for (size_t i = 0; i < dir1_files.count; i++) {
        for (size_t j = 0; j < dir2_files.count; j++) {
            if (compare_file_info(dir1_files.files[i], dir2_files.files[j]) == 0) {
                printf("Одинаковые файлы найдены:\n");
                print_file_info(stdout, dir1_files.files[i]);
                print_file_info(stdout, dir2_files.files[j]);

                fprintf(output_file, "Одинаковые файлы найдены:\n");
                print_file_info(output_file, dir1_files.files[i]);
                print_file_info(output_file, dir2_files.files[j]);
            }
        }
    }


    fclose(output_file);
    file_list_free(&dir1_files);
    file_list_free(&dir2_files);

    return 0;
}
